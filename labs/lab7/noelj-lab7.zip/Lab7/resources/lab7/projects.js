{
    "projects": [
        {
            "name": "Lab 2",
            "desc": "Resume",
            "url": "./resources/lab2/JosephNoel-resume.html",
            "pic": "./resources/lab2/resume_preview.png"
        },
        {
            "name": "Lab 3",
            "desc": "Website",
            "url": "./index.html",
            "pic": "./resources/house.png"
        },
        {
            "name": "Lab 4",
            "desc": "XML/RSS",
            "url": "./resources/lab4/RSS.xml",
            "pic": "./resources/lab4/rss_preview.png"
        },
        {
            "name": "Lab 4",
            "desc": "XML/ATOM",
            "url": "./resources/lab4/ATOM.xml",
            "pic": "./resources/lab4/atom_preview.png"
        },
        {
            "name": "Lab 5",
            "desc": "Javascript",
            "url": "./resources/lab5/lab5.html",
            "pic": "./resources/lab5/lab_5_preview.png"
        },
        {
            "name": "Lab 6",
            "desc": "jQuery",
            "url": "./resources/lab6/lab6.html",
            "pic": "./resources/lab6/lab6_preview.png"
        }
    ]
}
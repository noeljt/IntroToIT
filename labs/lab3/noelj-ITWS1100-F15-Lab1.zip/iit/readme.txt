URL: https://afsws.rpi.edu/AFS/home/00/noelj/public_html/iit/

For my menu I chose a vertical menu on the right side, simply because it's where I prefer menus.
Every object has a border within (so as not to go past the 100% width/height settings) in addition to a background image to help distinguish content from the full-page background image.

For my home page, I put a picture of an ascii style house, simply because it's the home page and I thought I regular image would be boring (as a result I learned what the <pre> tag is for, even though I ended up not using it due to sizing issues).

For my projects page, I wanted a preview of the project available below the name of the project, and once there's more projects it will have almost be a tile-like menu (at least that's the idea).

The quotes were just for fun, didn't originally plan on keeping them, but they help fill space so why not?

Both the home image and project list are centered on page just because I thought it looked better with the tons of empty space I have on my monitors, although when I viewed them on smaller windows the center div would sometimes overlap the header or footer, it would probably be unwise for a mobile device.